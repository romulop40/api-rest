export const environment = {
  production: true,
  apiURL: 'https://todo-api-cds.herokuapp.com/api/todos'
};
